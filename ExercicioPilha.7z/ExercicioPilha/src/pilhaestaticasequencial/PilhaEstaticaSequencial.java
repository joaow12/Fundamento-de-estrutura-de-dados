package pilhaestaticasequencial;

import javax.swing.JOptionPane;

public class PilhaEstaticaSequencial {
    
    private Pilha p = null;
    
    public static void main(String[] args) {
        new PilhaEstaticaSequencial();
    }
    
    public PilhaEstaticaSequencial() {
       simulacaoLeituraDeDados();      
       System.out.println("Pilha inicial:");
       System.out.println( p.toString() );       
       System.out.println("Retirando e esvaziando a pilha:");
       while ( !p.isEmpty() ) {
           Carro ca = (Carro)p.pop();
           System.out.println(ca);
           if(ca.getAno() > 2010)System.out.println("  -- O Carro foi fabricado depois de 2010");
       }
       if ( p.isEmpty() ) System.out.println("Impossível retirar da pilha. Pilha vazia.");     
    }
    
    public void simulacaoLeituraDeDados() {
        //para efetuar teste rápidos, criamos uma pilha com dados fixos:
        p = new Pilha(7);
        p.push( new Carro("800F5X", "Audi", "Sedan", 2012) );
        p.push( new Carro("568FG21", "Chevrolet", "Caminhonete", 2003) );
        p.push( new Carro("756335GA", "Citroen", "Sedan", 2008) );
        p.push( new Carro("8GAG953", "FIAT", "Esportivo", 2016) );
        p.push( new Carro("ATSG8731", "Porsche", "Esportivo", 2018) );
        p.push( new Carro("8054G2S", "Volvo", "Caminhão", 1998) );
        p.push( new Carro("3A4G205", "Chevrolet", "Potente", 1978) );
    }
    
    public void leituraDeDados () {
        String umPlaca; String umMarca; String umModelo; int umAno;
        int N = Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de Carros"));
        p = new Pilha(N);   //aloca memória para a pilha
        for (int i=0; i<N; i++){
                  umPlaca = JOptionPane.showInputDialog( "Digite uma placa de carro ");
                  umMarca = JOptionPane.showInputDialog( "Digite uma marca de carro: ");
                  umModelo= JOptionPane.showInputDialog( "Digite um modelo de carro: ");
                  umAno = Integer.parseInt(JOptionPane.showInputDialog("Digite o ano de fabricação do carro"));
                  p.push( new Carro(umPlaca, umMarca, umModelo, umAno) );
        }
    }
    
}
