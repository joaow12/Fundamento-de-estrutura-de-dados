package pilhaestaticasequencial;

import javax.swing.*;

public class Carro {
    
    private String placa;
    private String marca;
    private String modelo;
    private int ano;
    
    public Carro(){
        
        placa = "-";
        marca = "-";
        modelo = "-";
        ano = 0;
    }
    
    public Carro(String inPlaca, String inMarca, String inModelo, int inAno){
        
        setPlaca(inPlaca);
        setMarca(inMarca);
        setModelo(inModelo);
        setAno(inAno);
    }
    
    public void setPlaca(String inPlaca){
        placa = inPlaca;
    }
    
    public void setMarca(String inMarca){
        marca = inMarca;
    }
    
    public void setModelo(String inModelo){
        modelo = inModelo;
    }
    
    public void setAno(int inAno){
        ano = inAno;
    }
    
    public String getPlaca(){
        return placa;
    }
    
    public String getMarca(){
        return marca;
    }
    
    public String getModelo(){
        return modelo;
    }
    
    public int getAno(){
        return ano;
    }
    
    public String toString()  {
       return("Marca do carro: " + getMarca() + "\nModelo do carro: " + getModelo() + "\nPlaca do carro: " + getPlaca() + "\nAno de fabricação: " + getAno());
   }
}
